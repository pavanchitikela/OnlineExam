package com.exam.pojo;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the EXAMLEVEL database table.
 * 
 */
@Entity
@NamedQuery(name="Examlevel.findAll", query="SELECT e FROM Examlevel e")
public class Examlevel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int elid;

	//bi-directional many-to-one association to Exam
	@ManyToOne
	@JoinColumn(name="EXAMID")
	private Exam exam;

	//bi-directional many-to-one association to Level
	@ManyToOne
	@JoinColumn(name="LEVELID")
	private Level level;

	//bi-directional many-to-one association to Question
	@OneToMany(mappedBy="examlevel")
	private List<Question> questions;

	//bi-directional many-to-one association to Result
	@OneToMany(mappedBy="examlevel")
	private List<Result> results;

	public Examlevel() {
	}

	public int getElid() {
		return this.elid;
	}

	public void setElid(int elid) {
		this.elid = elid;
	}

	public Exam getExam() {
		return this.exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	public Level getLevel() {
		return this.level;
	}

	public void setLevel(Level level) {
		this.level = level;
	}

	public List<Question> getQuestions() {
		return this.questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	public Question addQuestion(Question question) {
		getQuestions().add(question);
		question.setExamlevel(this);

		return question;
	}

	public Question removeQuestion(Question question) {
		getQuestions().remove(question);
		question.setExamlevel(null);

		return question;
	}

	public List<Result> getResults() {
		return this.results;
	}

	public void setResults(List<Result> results) {
		this.results = results;
	}

	public Result addResult(Result result) {
		getResults().add(result);
		result.setExamlevel(this);

		return result;
	}

	public Result removeResult(Result result) {
		getResults().remove(result);
		result.setExamlevel(null);

		return result;
	}

}