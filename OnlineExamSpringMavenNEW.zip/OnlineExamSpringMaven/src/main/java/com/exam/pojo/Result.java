package com.exam.pojo;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "RESULT" database table.
 * 
 */
@Entity
@Table(name="\"RESULT\"")
@NamedQuery(name="Result.findAll", query="SELECT r FROM Result r")
public class Result implements Serializable {
	private static final long serialVersionUID = 1L;

	private int attemptedqs;

	private int crctans;

	private int incrctans;

	private int marksscored;

	private int nonattemptedqs;

	private Double percentage;

	private String status;

	//bi-directional many-to-one association to Examlevel
	@ManyToOne
	@JoinColumn(name="ELID")
	private Examlevel examlevel;

	//bi-directional many-to-one association to Examuser
	@ManyToOne
	@JoinColumn(name="USERID")
	private Examuser examuser;

	public Result() {
	}

	public int getAttemptedqs() {
		return this.attemptedqs;
	}

	public void setAttemptedqs(int attemptedqs) {
		this.attemptedqs = attemptedqs;
	}

	public int getCrctans() {
		return this.crctans;
	}

	public void setCrctans(int crctans) {
		this.crctans = crctans;
	}

	public int getIncrctans() {
		return this.incrctans;
	}

	public void setIncrctans(int incrctans) {
		this.incrctans = incrctans;
	}

	public int getMarksscored() {
		return this.marksscored;
	}

	public void setMarksscored(int marksscored) {
		this.marksscored = marksscored;
	}

	public int getNonattemptedqs() {
		return this.nonattemptedqs;
	}

	public void setNonattemptedqs(int nonattemptedqs) {
		this.nonattemptedqs = nonattemptedqs;
	}

	public Double getPercentage() {
		return this.percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Examlevel getExamlevel() {
		return this.examlevel;
	}

	public void setExamlevel(Examlevel examlevel) {
		this.examlevel = examlevel;
	}

	public Examuser getExamuser() {
		return this.examuser;
	}

	public void setExamuser(Examuser examuser) {
		this.examuser = examuser;
	}

}