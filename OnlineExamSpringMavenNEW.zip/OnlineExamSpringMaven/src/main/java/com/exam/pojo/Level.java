package com.exam.pojo;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the LEVELS database table.
 * 
 */
@Entity
@Table(name="LEVELS")
@NamedQuery(name="Level.findAll", query="SELECT l FROM Level l")
public class Level implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int levelid;

	private int cutoffmarks;

	private int duration;

	private int qstcount;

	//bi-directional many-to-one association to Examlevel
	@OneToMany(mappedBy="level")
	private List<Examlevel> examlevels;

	public Level() {
	}

	public int getLevelid() {
		return this.levelid;
	}

	public void setLevelid(int levelid) {
		this.levelid = levelid;
	}

	public int getCutoffmarks() {
		return this.cutoffmarks;
	}

	public void setCutoffmarks(int cutoffmarks) {
		this.cutoffmarks = cutoffmarks;
	}

	public int getDuration() {
		return this.duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getQstcount() {
		return this.qstcount;
	}

	public void setQstcount(int qstcount) {
		this.qstcount = qstcount;
	}

	public List<Examlevel> getExamlevels() {
		return this.examlevels;
	}

	public void setExamlevels(List<Examlevel> examlevels) {
		this.examlevels = examlevels;
	}

	public Examlevel addExamlevel(Examlevel examlevel) {
		getExamlevels().add(examlevel);
		examlevel.setLevel(this);

		return examlevel;
	}

	public Examlevel removeExamlevel(Examlevel examlevel) {
		getExamlevels().remove(examlevel);
		examlevel.setLevel(null);

		return examlevel;
	}

}