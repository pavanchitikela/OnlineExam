package com.exam.pojo;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the EXAM database table.
 * 
 */
@Entity
@NamedQuery(name="Exam.findAll", query="SELECT e FROM Exam e")
public class Exam implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int examid;

	private String endtime;

	@Temporal(TemporalType.DATE)
	private Date exdate;

	private String exname;

	private String starttime;

	//bi-directional many-to-one association to Examlevel
	@OneToMany(mappedBy="exam")
	private List<Examlevel> examlevels;

	public Exam() {
	}

	public int getExamid() {
		return this.examid;
	}

	public void setExamid(int examid) {
		this.examid = examid;
	}

	public String getEndtime() {
		return this.endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public Date getExdate() {
		return this.exdate;
	}

	public void setExdate(Date exdate) {
		this.exdate = exdate;
	}

	public String getExname() {
		return this.exname;
	}

	public void setExname(String exname) {
		this.exname = exname;
	}

	public String getStarttime() {
		return this.starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}

	public List<Examlevel> getExamlevels() {
		return this.examlevels;
	}

	public void setExamlevels(List<Examlevel> examlevels) {
		this.examlevels = examlevels;
	}

	public Examlevel addExamlevel(Examlevel examlevel) {
		getExamlevels().add(examlevel);
		examlevel.setExam(this);

		return examlevel;
	}

	public Examlevel removeExamlevel(Examlevel examlevel) {
		getExamlevels().remove(examlevel);
		examlevel.setExam(null);

		return examlevel;
	}

}